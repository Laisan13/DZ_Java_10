public class Main {
    public static void main(String[] args) {
        //Задание из собеседования Яндекс:
        //дана строка вида AAAABBBCCCDDEG…,
        // состоящая только из заглавных символов латинского алфавита.
        // Напишите метод, который «свернёт» строку к виду A4B3C3D2EG,
        // т.е. количество букв записывается цифрой.
        // Если буква одна, то цифра не ставится.
        String str = "AAAABBBCCCDDEGGF";
        System.out.println(result(str));



    }

    private static String result(String str) {
        StringBuilder strs = new StringBuilder();
        String letter = String.valueOf(str.charAt(0));
        int b = 1;
        for (int i = 1; i < str.length(); i++) {
            if (!letter.equals(String.valueOf(str.charAt(i)))) {
                strs.append(letter);
                if (b > 1) {
                    strs.append(b);
                }
                b = 1;
                letter = String.valueOf(str.charAt(i));
                if (letter.equals(String.valueOf(str.charAt(str.length() - 1)))) {
                    strs.append(letter);
                }
            } else b++;
        }
        String result = strs.toString();
        return result;

    }


}


