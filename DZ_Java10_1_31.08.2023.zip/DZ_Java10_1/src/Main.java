import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        char letter = 'А';
        String[][] alphabet = new String[3][];

        for (int i = 0; i < alphabet.length; i++) {

            alphabet[i] = new String[11];

            for (int j = 0; j < alphabet[i].length; j++) {

                if (j == 6) {
                    alphabet[i][j] = String.valueOf( 'Ё' );
                    continue;
                }
                if (letter != 'Ё') {
                    alphabet[i][j] = String.valueOf(letter);
                }

                letter++;

            }



        }
        System.out.println(Arrays.deepToString(alphabet));

    }
}